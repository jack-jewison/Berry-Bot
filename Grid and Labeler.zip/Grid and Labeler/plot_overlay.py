import os
import pandas as pd
import matplotlib.pyplot as plt
from exif import Image as ExifImage

def dms_to_decimal(dms, ref):
    degrees, minutes, seconds = dms
    decimal = degrees + minutes / 60 + seconds / 3600
    if ref in ['S', 'W']:
        decimal = -decimal
    return decimal

def get_image_gps(image_path):
    try:
        with open(image_path, 'rb') as img_file:
            img = ExifImage(img_file)
            if not img.has_exif:
                return None
            if not hasattr(img, 'gps_latitude') or not hasattr(img, 'gps_longitude'):
                return None
            lat = dms_to_decimal(img.gps_latitude, img.gps_latitude_ref)
            lon = dms_to_decimal(img.gps_longitude, img.gps_longitude_ref)
            return lat, lon
    except Exception as e:
        print(f"Error reading {image_path}: {e}")
        return None

def plot_all_image_gps(csv_path, image_folder):
    # Load reference points
    df = pd.read_csv(csv_path)

    # Prepare plot
    plt.figure(figsize=(10, 8))
    plt.scatter(df['longitude'], df['latitude'], c='blue', s=60)


    # Process images
    for filename in os.listdir(image_folder):
        if filename.lower().endswith(('.jpg', '.jpeg')):
            path = os.path.join(image_folder, filename)
            gps = get_image_gps(path)
            if gps:
                lat, lon = gps
                plt.scatter(lon, lat, c='red', marker='X', s=80)
                plt.text(lon, lat, filename, fontsize=7, ha='left')

    plt.xlabel("Longitude")
    plt.ylabel("Latitude")
    plt.title("GPS Overlay: CSV Points + All Images in Folder")
    plt.grid(True)
    plt.tight_layout()
    plt.show()

# Example usage
if __name__ == "__main__":
    plot_all_image_gps("labels.csv", "img")
