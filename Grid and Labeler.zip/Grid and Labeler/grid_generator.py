import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Define the four corner points (in decimal degrees)
lat_top_left = 44.18588333333333
lon_top_left = -90.74761944444444

lat_top_right = 44.186027777777774
lon_top_right = -90.74731666666666

lat_bottom_left = 44.18569166666666
lon_bottom_left = -90.74744166666667

lat_bottom_right = 44.18583611111111
lon_bottom_right = -90.74713888888888

# Grid dimensions
rows, cols = 20, 18

# Initialize grid arrays
grid_lat = np.zeros((rows, cols))
grid_lon = np.zeros((rows, cols))
grid_index = []

# Generate the grid with interpolation
for i in range(rows):
    t = 1 - (i / (rows - 1))  # Start from bottom (lower-left)

    lat_left = (1 - t) * lat_top_left + t * lat_bottom_left
    lon_left = (1 - t) * lon_top_left + t * lon_bottom_left
    lat_right = (1 - t) * lat_top_right + t * lat_bottom_right
    lon_right = (1 - t) * lon_top_right + t * lon_bottom_right

    for j in range(cols):
        s = j / (cols - 1)
        lat = (1 - s) * lat_left + s * lat_right
        lon = (1 - s) * lon_left + s * lon_right
        grid_lat[i, j] = lat
        grid_lon[i, j] = lon
        grid_index.append((f"Grid_{i+1}_{j+1}", lat, lon))

# Create DataFrame with labels
df = pd.DataFrame(grid_index, columns=["label", "latitude", "longitude"])

# Export CSV
df.to_csv("interpolated_grid_output.csv", index=False)
print("CSV saved as interpolated_grid_output.csv")

# Plot the grid
plt.figure(figsize=(10, 6))
plt.scatter(df["longitude"], df["latitude"], c='blue', s=10)

# label a few points for clarity (e.g., every 5th point)
for idx, row in df.iterrows():
    if (idx % 15 == 0):  # adjust density as needed
        plt.text(row["longitude"], row["latitude"], row["label"], fontsize=6, ha='right')

plt.title("Interpolated 18×20 GPS Grid")
plt.xlabel("Longitude")
plt.ylabel("Latitude")
plt.gca().invert_xaxis()  # Flip for west-longitude
plt.grid(True)
plt.tight_layout()

